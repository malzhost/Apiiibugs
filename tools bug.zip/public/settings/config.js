global.creator = "@MalzXyz"
global.token = "7248065724:AAExb1Gt03dkaSO-IgacdCN9QRd3NZjgUJ0"
global.chatid = "7616707440"
global.watermark = "© MalzXyz"
